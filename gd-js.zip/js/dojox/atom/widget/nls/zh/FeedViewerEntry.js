//>>built
define(
//begin v1.x content
({
	deleteButton: "[删除]"
})
//end v1.x content
);
