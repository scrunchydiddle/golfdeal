//>>built
define(
//begin v1.x content
({
	deleteButton: "[ลบ]"
})
//end v1.x content
);
