//>>built
define(
//begin v1.x content
({
	doNew: "[สร้าง]",
	edit: "[แก้ไข]",
	save: "[บันทึก]",
	cancel: "[ยกเลิก]"
})
//end v1.x content
);
