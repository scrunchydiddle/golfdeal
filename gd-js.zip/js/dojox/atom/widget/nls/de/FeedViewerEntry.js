//>>built
define(
//begin v1.x content
({
	deleteButton: "[Löschen]"
})
//end v1.x content
);
