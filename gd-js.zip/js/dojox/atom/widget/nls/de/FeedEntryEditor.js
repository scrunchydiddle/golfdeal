//>>built
define(
//begin v1.x content
({
	doNew: "[Neu]",
	edit: "[Bearbeiten]",
	save: "[Speichern]",
	cancel: "[Abbrechen]"
})
//end v1.x content
);
