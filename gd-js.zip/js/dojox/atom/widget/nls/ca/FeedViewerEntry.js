//>>built
define(
//begin v1.x content
({
	deleteButton: "[Suprimeix]"
})
//end v1.x content
);
