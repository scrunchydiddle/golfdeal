//>>built
define(
//begin v1.x content
({
	doNew: "[nou]",
	edit: "[edita]",
	save: "[desa]",
	cancel: "[cancel·la]"
})
//end v1.x content
);
