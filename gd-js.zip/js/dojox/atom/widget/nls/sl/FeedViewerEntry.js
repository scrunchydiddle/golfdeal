//>>built
define(
//begin v1.x content
({
	deleteButton: "[Izbriši]"
})
//end v1.x content
);
