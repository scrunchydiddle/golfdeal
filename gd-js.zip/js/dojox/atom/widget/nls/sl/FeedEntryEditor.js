//>>built
define(
//begin v1.x content
({
	doNew: "[novo]",
	edit: "[urejanje]",
	save: "[shrani]",
	cancel: "[prekliči]"
})
//end v1.x content
);
