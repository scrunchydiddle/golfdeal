//>>built
define(
//begin v1.x content
({
	add: "Dodaj",
	addAuthor: "Dodaj avtorja",
	addContributor: "Dodaj kontributorja"
})
//end v1.x content
);
