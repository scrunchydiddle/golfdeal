//>>built
define(
//begin v1.x content
({
	displayOptions: "[možnosti prikaza]",
	title: "Naslov",
	authors: "Avtorji",
	contributors: "Kontributorji",
	id: "ID",
	close: "[zapri]",
	updated: "Posodobljeno",
	summary: "Povzetek",
	content: "Vsebina"
})
//end v1.x content
);
