//>>built
define(
//begin v1.x content
({
	doNew: "[nowy]",
	edit: "[edytuj]",
	save: "[zapisz]",
	cancel: "[anuluj]"
})
//end v1.x content
);
