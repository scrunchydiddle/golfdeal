//>>built
define(
//begin v1.x content
({
	add: "Dodaj",
	addAuthor: "Dodaj autora",
	addContributor: "Dodaj kontrybutora"
})
//end v1.x content
);
