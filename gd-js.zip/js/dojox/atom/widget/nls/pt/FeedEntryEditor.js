//>>built
define(
//begin v1.x content
({
	doNew: "[novo]",
	edit: "[editar]",
	save: "[salvar]",
	cancel: "[cancelar]"
})
//end v1.x content
);
