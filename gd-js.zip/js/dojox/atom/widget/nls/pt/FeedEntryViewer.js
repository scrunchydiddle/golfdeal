//>>built
define(
//begin v1.x content
({
	displayOptions: "[exibir opções]",
	title: "Título",
	authors: "Autores",
	contributors: "Contribuidores",
	id: "ID",
	close: "[fechar]",
	updated: "Atualizado",
	summary: "Resumo",
	content: "Conteúdo"
})
//end v1.x content
);
