//>>built
define(
//begin v1.x content
({
	deleteButton: "[Excluir]"
})
//end v1.x content
);
