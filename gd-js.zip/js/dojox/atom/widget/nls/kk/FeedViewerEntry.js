//>>built
define(
//begin v1.x content
({
	deleteButton: "[Жою]"
})
//end v1.x content
);
