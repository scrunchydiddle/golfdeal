//>>built
define(
//begin v1.x content
({
	doNew: "[жаңа]",
	edit: "[өңдеу]",
	save: "[сақтау]",
	cancel: "[болдырмау]"
})
//end v1.x content
);
