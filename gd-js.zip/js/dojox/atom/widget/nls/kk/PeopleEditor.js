//>>built
define(
//begin v1.x content
({
	add: "Қосу",
	addAuthor: "Авторды қосу",
	addContributor: "Салымшыны қосу"
})
//end v1.x content
);
