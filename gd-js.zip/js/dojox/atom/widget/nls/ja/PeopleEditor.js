//>>built
define(
//begin v1.x content
({
	add: "追加",
	addAuthor: "作成者の追加",
	addContributor: "貢献者の追加"
})
//end v1.x content
);
