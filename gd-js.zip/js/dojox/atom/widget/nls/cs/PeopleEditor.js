//>>built
define(
//begin v1.x content
({
	add: "Přidat",
	addAuthor: "Přidat autora",
	addContributor: "Přidat přispěvatele"
})
//end v1.x content
);
