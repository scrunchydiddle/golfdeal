//>>built
define(
//begin v1.x content
({
	displayOptions: "[Visningsalternativ]",
	title: "Rubrik",
	authors: "Författare",
	contributors: "Medverkande",
	id: "ID",
	close: "[Stäng]",
	updated: "Uppdaterat",
	summary: "Sammanfattning",
	content: "Innehåll"
})
//end v1.x content
);
