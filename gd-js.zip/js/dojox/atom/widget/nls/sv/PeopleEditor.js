//>>built
define(
//begin v1.x content
({
	add: "Lägg till",
	addAuthor: "Lägg till författare",
	addContributor: "Lägg till medverkande"
})
//end v1.x content
);
