//>>built
define(
//begin v1.x content
({
	add: "Adicionar",
	addAuthor: "Adicionar autor",
	addContributor: "Adicionar contribuinte"
})
//end v1.x content
);
