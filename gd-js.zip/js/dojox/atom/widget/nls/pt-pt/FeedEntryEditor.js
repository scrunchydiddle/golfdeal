//>>built
define(
//begin v1.x content
({
	doNew: "[novo]",
	edit: "[editar]",
	save: "[guardar]",
	cancel: "[cancelar]"
})
//end v1.x content
);
