//>>built
define(
//begin v1.x content
({
	"add" : "Əlavə Et",
	"addAuthor" : "Yazıçı Əlavə Et",
	"addContributor" : "Əməyi keçənlərə Əlavə Et"
})
//end v1.x content
);