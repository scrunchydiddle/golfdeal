//>>built
define(
//begin v1.x content
({
	deleteButton: "[Удалить]"
})
//end v1.x content
);
