//>>built
define(
//begin v1.x content
({
	displayOptions: "[показать опции]",
	title: "Название",
	authors: "Авторы",
	contributors: "Участники",
	id: "ИД",
	close: "[закрыть]",
	updated: "Обновлено",
	summary: "Сводка",
	content: "Информационное наполнение"
})
//end v1.x content
);
