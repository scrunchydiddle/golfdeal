//>>built
define(
//begin v1.x content
({
	add: "Добавить",
	addAuthor: "Добавить автора",
	addContributor: "Добавить участника"
})
//end v1.x content
);
