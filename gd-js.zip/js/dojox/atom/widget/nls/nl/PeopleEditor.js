//>>built
define(
//begin v1.x content
({
	add: "Toevoegen",
	addAuthor: "Auteur toevoegen",
	addContributor: "Deelnemer toevoegen"
})
//end v1.x content
);
