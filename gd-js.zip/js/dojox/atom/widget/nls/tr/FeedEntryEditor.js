//>>built
define(
//begin v1.x content
({
	doNew: "[yeni]",
	edit: "[düzenle]",
	save: "[kaydet]",
	cancel: "[iptal]"
})
//end v1.x content
);
