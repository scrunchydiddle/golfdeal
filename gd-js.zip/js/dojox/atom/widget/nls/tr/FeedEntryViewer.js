//>>built
define(
//begin v1.x content
({
	displayOptions: "[görüntüleme seçenekleri]",
	title: "Başlık",
	authors: "Yazarlar",
	contributors: "Katkıda Bulunanlar",
	id: "Kimlik",
	close: "[kapat]",
	updated: "Güncelleştirildi",
	summary: "Özet",
	content: "İçerik"
})
//end v1.x content
);
