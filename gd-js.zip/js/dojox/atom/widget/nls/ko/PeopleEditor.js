//>>built
define(
//begin v1.x content
({
	add: "추가",
	addAuthor: "작성자 추가",
	addContributor: "제공자 추가"
})
//end v1.x content
);
