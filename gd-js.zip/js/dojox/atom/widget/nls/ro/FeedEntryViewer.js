//>>built
define(
//begin v1.x content
({
	displayOptions: "[opţiuni afişare]",
	title: "Titlu",
	authors: "Autori",
	contributors: "Contribuitori",
	id: "ID",
	close: "[închidere]",
	updated: "Actualizat",
	summary: "Sumar",
	content: "Conţinut"
})
//end v1.x content
);
