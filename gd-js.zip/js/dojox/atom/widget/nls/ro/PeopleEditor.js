//>>built
define(
//begin v1.x content
({
	add: "Adăugare",
	addAuthor: "Adăugare autor",
	addContributor: "Adăugare contribuitor"
})
//end v1.x content
);
