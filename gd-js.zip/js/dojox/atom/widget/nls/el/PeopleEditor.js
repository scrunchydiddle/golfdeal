//>>built
define(
//begin v1.x content
({
	add: "Προσθήκη",
	addAuthor: "Προσθήκη συντάκτη",
	addContributor: "Προσθήκη συνεισφέροντα"
})
//end v1.x content
);
