//>>built
define(
//begin v1.x content
({
	displayOptions: "[顯示選項]",
	title: "標題",
	authors: "作者",
	contributors: "貢獻者",
	id: "ID",
	close: "[關閉]",
	updated: "已更新",
	summary: "摘要",
	content: "內容"
})
//end v1.x content
);
