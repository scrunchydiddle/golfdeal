//>>built
define(
//begin v1.x content
({
	add: "Hozzáadás",
	addAuthor: "Szerző hozzáadása",
	addContributor: "Közreműködő hozzáadása"
})
//end v1.x content
);
