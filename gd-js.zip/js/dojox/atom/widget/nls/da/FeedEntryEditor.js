//>>built
define(
//begin v1.x content
({
	doNew: "[ny]",
	edit: "[redigér]",
	save: "[gem]",
	cancel: "[annullér]"
})
//end v1.x content
);
