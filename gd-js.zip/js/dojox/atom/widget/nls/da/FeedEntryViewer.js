//>>built
define(
//begin v1.x content
({
	displayOptions: "[fremvisningsvalg]",
	title: "Titel",
	authors: "Forfattere",
	contributors: "Bidragydere",
	id: "Id",
	close: "[luk]",
	updated: "Opdateret",
	summary: "Resumé",
	content: "Indhold"
})
//end v1.x content
);
