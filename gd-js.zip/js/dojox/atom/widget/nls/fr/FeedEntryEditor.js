//>>built
define(
//begin v1.x content
({
	doNew: "[nouveau]",
	edit: "[éditer]",
	save: "[sauvegarder]",
	cancel: "[annuler]"
})
//end v1.x content
);
