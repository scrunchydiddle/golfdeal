//>>built
define(
//begin v1.x content
({
	deleteButton: "[Supprimer]"
})
//end v1.x content
);
