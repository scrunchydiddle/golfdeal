//>>built
define(
//begin v1.x content
({
	displayOptions: "[options d'affichage]",
	title: "Titre",
	authors: "Auteurs",
	contributors: "Collaborateurs",
	id: "ID",
	close: "[fermer]",
	updated: "Mis à jour",
	summary: "Récapitulatif",
	content: "Contenu"
})
//end v1.x content
);
