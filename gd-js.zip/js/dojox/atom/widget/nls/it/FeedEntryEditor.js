//>>built
define(
//begin v1.x content
({
	doNew: "[nuovo]",
	edit: "[modifica]",
	save: "[salva]",
	cancel: "[annulla]"
})
//end v1.x content
);
