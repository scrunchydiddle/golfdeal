//>>built
define(
//begin v1.x content
({
	doNew: "[uusi]",
	edit: "[muokkaa]",
	save: "[tallenna]",
	cancel: "[peruuta]"
})
//end v1.x content
);
