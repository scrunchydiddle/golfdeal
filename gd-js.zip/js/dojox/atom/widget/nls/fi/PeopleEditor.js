//>>built
define(
//begin v1.x content
({
	add: "Lisää",
	addAuthor: "Lisää tekijä",
	addContributor: "Lisää lisääjä"
})
//end v1.x content
);
