//>>built
define(
//begin v1.x content
({
	add: "Pridať",
	addAuthor: "Pridať autora",
	addContributor: "Pridať prispievateľa"
})
//end v1.x content
);
