//>>built
define(
//begin v1.x content
({
	doNew: "[nový]",
	edit: "[upraviť]",
	save: "[uložiť]",
	cancel: "[zrušiť]"
})
//end v1.x content
);
