//>>built
define(
//begin v1.x content
({
	insertImageTitle: "插入影像",
	url: "影像",
	browse: "瀏覽...",
	text: "說明",
	set: "插入",
	invalidMessage: "影像檔類型無效",
	prePopuTextUrl: "輸入影像 URL",
	prePopuTextBrowse: " 或瀏覽本端檔案。"
})
//end v1.x content
);
