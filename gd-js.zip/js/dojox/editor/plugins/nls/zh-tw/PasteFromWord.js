//>>built
define(
//begin v1.x content
({
	"pasteFromWord": "從 Word 貼上",
	"paste": "貼上",
	"cancel": "取消",
	"instructions": "將 Word 中的內容貼入下方的文字框。在滿意要插入的內容之後，請按貼上按鈕。若要中斷插入文字，請按取消按鈕。"
})
//end v1.x content
);
