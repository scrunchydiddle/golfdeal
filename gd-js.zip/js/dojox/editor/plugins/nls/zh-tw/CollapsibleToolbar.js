//>>built
define(
//begin v1.x content
({
	"collapse": "收合編輯器工具列",
	"expand": "展開編輯器工具列"
})
//end v1.x content
);
