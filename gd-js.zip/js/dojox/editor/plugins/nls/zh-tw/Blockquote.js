//>>built
define(
//begin v1.x content
({
	"blockquote": "區塊引文"
})
//end v1.x content
);
