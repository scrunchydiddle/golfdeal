//>>built
define(
//begin v1.x content
({
	"showBlockNodes": "顯示 HTML 區塊元素"
})

//end v1.x content
);
