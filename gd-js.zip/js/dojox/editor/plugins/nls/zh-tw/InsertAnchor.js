//>>built
define(
//begin v1.x content
({
	insertAnchor: "插入錨點",
	title: "錨點內容",
	anchor: "名稱：",
	text: "說明：",
	set: "設定",
	cancel: "取消"
})
//end v1.x content
);
