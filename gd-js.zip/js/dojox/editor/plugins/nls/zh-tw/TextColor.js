//>>built
define(
//begin v1.x content
({
	"setButtonText": "設定",
	"cancelButtonText": "取消"
})
//end v1.x content
);
