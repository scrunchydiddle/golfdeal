//>>built
define(
//begin v1.x content
({
	"save": "儲存"
})

//end v1.x content
);
