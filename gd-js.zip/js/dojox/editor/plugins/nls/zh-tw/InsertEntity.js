//>>built
define(
//begin v1.x content
({
	insertEntity: "插入符號"
})

//end v1.x content
);
