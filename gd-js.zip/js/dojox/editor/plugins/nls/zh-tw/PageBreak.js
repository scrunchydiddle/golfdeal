//>>built
define(
//begin v1.x content
({
	"pageBreak": "分頁"
})

//end v1.x content
);
