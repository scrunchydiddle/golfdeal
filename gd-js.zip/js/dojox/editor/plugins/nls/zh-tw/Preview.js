//>>built
define(
//begin v1.x content
({
	"preview": "預覽"
})

//end v1.x content
);
