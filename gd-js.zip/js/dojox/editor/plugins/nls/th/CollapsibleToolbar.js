//>>built
define(
//begin v1.x content
({
	"collapse": "ยุบรวมแถบเครื่องมือตัวแก้ไข",
	"expand": "ขยายแถบเครื่องมือตัวแก้ไข"
})

//end v1.x content
);
