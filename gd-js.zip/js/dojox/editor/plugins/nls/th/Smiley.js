//>>built
define(
//begin v1.x content
({
	smiley: "แทรกไอคอนแสดงอารมณ์",
	emoticonSmile: "ยิ้ม",
	emoticonLaughing: "หัวเราะ",
	emoticonWink: "ขยิบตา",
	emoticonGrin: "ยิ้มกว้าง",
	emoticonCool: "เจ๋ง",
	emoticonAngry: "โกรธ",
	emoticonHalf: "ครึ่งซีก",
	emoticonEyebrow: "คิ้ว",
	emoticonFrown: "หน้าบึ้ง",
	emoticonShy: "อาย",
	emoticonGoofy: "โง่",
	emoticonOops: "oops",
	emoticonTongue: "แลบลิ้น",
	emoticonIdea: "ความคิด",
	emoticonYes: "ใช่",
	emoticonNo: "ไม่ใช่",
	emoticonAngel: "โมโห",
	emoticonCrying: "ร้องไห้"
})

//end v1.x content
);
