//>>built
define(
//begin v1.x content
({
	insertEntity: "แทรกสัญลักษณ์"
})

//end v1.x content
);
