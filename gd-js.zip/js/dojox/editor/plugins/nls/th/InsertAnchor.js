//>>built
define(
//begin v1.x content
({
	insertAnchor: "แทรกจุดยึด",
	title: "คุณสมบัติจุดยึด",
	anchor: "ชื่อ:",
	text: "รายละเอียด",
	set: "ตั้งค่า",
	cancel: "ยกเลิก"
})

//end v1.x content
);
