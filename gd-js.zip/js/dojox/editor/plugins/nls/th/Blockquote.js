//>>built
define(
//begin v1.x content
({
	"blockquote": "บล็อกคำพูด"
})

//end v1.x content
);
