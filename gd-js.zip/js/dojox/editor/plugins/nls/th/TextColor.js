//>>built
define(
//begin v1.x content
({
	"setButtonText": "เซ็ต",
	"cancelButtonText": "ยกเลิก"
})

//end v1.x content
);
