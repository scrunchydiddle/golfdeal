//>>built
define(
//begin v1.x content
({
	"findLabel": "ค้นหา:",
	"findTooltip": "ป้อนข้อความเพื่อหา",
	"replaceLabel": "แทนที่ด้วย:",
	"replaceTooltip": "ป้อนข้อความเพื่อแทนที่ด้วย",
	"findReplace": "ค้นหาและแทนที่",
	"matchCase": "ตรงตามตัวพิมพ์ใหญ่เล็ก",
	"matchCaseTooltip": "ตรงตามตัวพิมพ์ใหญ่เล็ก",
	"backwards": "ย้อนกลับ",
	"backwardsTooltip": "ค้นหาย้อนกับเพื่อหาข้อความ",
	"replaceAll": "ที่เกิดขึ้นทั้งหมด",
	"replaceAllButton": "แทนที่ทั้งหมด",
	"replaceAllButtonTooltip": "แทนที่ข้อความทั้งหมด",
	"findButton": "ค้นหา",
	"findButtonTooltip": "หาข้อความ",
	"replaceButton": "แทนที่",
	"replaceButtonTooltip": "แทนที่ข้อความ",
	"replaceDialogText": "แทนที่ ${0} ที่เกิดขึ้น",
	"eofDialogText": "การเกิดขึ้นล่าสุด ${0}",
	"eofDialogTextFind": "หาพบ",
	"eofDialogTextReplace": "ถูกแทนที่"
})

//end v1.x content
);
