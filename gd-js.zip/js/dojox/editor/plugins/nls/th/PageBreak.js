//>>built
define(
//begin v1.x content
({
	"pageBreak": "เส้นกั้นหน้า"
})

//end v1.x content
);
