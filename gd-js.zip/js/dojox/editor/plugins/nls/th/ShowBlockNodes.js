//>>built
define(
//begin v1.x content
({
	"showBlockNodes": "แสดงอิลิเมนต์บล็อก HTML"
})

//end v1.x content
);
