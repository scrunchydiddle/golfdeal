//>>built
define(
//begin v1.x content
({
	"nodeActions": "${nodeName} แอ็คชัน",
	"selectContents": "เลือกเนื้อหา",
	"selectElement": "เลือกอิลิเมนต์",
	"deleteElement": "ลบอิลิเมนต์",
	"deleteContents": "ลบเนื้อหา",
	"moveStart": "ย้ายเคอร์เซอร์ไปยังจุดเริ่มต้น",
	"moveEnd": "ย้ายเคอร์เซอร์ไปยังจุดสิ้นสุด"
})

//end v1.x content
);
