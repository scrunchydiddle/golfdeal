//>>built
define(
//begin v1.x content
({
	"preview": "แสดงตัวอย่าง"
})

//end v1.x content
);
