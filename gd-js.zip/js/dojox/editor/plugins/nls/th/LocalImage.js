//>>built
define(
//begin v1.x content
({
	insertImageTitle: "แทรกรูปภาพ",
	url: "รูปภาพ",
	browse: "เรียกดู...",
	text: "รายละเอียด",
	set: "แทรก",
	invalidMessage: "ชนิดของไฟล์รูปภาพไม่ถูกต้อง",
	prePopuTextUrl: "ป้อน URL ของรูปภาพ",
	prePopuTextBrowse: " หรือเรียกดูโลคัลไฟล์"
})

//end v1.x content
);
