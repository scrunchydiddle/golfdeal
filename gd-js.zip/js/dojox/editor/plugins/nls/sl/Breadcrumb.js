//>>built
define(
//begin v1.x content
({
	"nodeActions": "Dejanja ${nodeName} ",
	"selectContents": "Izberi vsebine ",
	"selectElement": "Izberi element ",
	"deleteElement": "Izbriši element ",
	"deleteContents": "Izbriši vsebine ",
	"moveStart": "Pomakni kazalko na začetek ",
	"moveEnd": "Pomakni kazalko na konec "
})

//end v1.x content
);
