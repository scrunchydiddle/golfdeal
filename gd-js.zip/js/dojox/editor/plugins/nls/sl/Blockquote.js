//>>built
define(
//begin v1.x content
({
	"blockquote": "Blokovno besedilo"
})

//end v1.x content
);
