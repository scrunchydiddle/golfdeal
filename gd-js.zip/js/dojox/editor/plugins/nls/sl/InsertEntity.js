//>>built
define(
//begin v1.x content
({
	insertEntity: "Vstavi simbol "
})

//end v1.x content
);
