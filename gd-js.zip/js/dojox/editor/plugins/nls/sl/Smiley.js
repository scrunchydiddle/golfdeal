//>>built
define(
//begin v1.x content
({
	smiley: "Vstavi čustveni simbol",
	emoticonSmile: "smeško",
	emoticonLaughing: "smeško z odprtimi usti",
	emoticonWink: "smeško pomežikne",
	emoticonGrin: "smeško se nasmehne do ušes",
	emoticonCool: "smeško je frajer",
	emoticonAngry: "smeško je jezen",
	emoticonHalf: "smeško se mršči",
	emoticonEyebrow: "smeško dviga obrv",
	emoticonFrown: "smeško ni zadovoljen",
	emoticonShy: "smeško je v zadregi",
	emoticonGoofy: "smeško se pači",
	emoticonOops: "smeško ga je polomil",
	emoticonTongue: "smeško kaže jezik",
	emoticonIdea: "ideja",
	emoticonYes: "smeško prikimava",
	emoticonNo: "smeško odkimava",
	emoticonAngel: "smeško je angelček",
	emoticonCrying: "smeško joka"
})

//end v1.x content
);
