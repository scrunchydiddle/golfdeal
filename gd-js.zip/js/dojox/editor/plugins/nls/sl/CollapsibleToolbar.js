//>>built
define(
//begin v1.x content
({
	"collapse": "Strni orodno vrstico urejevalnika ",
	"expand": "Razširi orodno vrstico urejevalnika "
})

//end v1.x content
);
