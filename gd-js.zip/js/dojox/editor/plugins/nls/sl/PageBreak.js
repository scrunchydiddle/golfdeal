//>>built
define(
//begin v1.x content
({
	"pageBreak": "Prelom strani"
})

//end v1.x content
);
