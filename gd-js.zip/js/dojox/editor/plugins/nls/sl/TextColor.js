//>>built
define(
//begin v1.x content
({
	"setButtonText": "Nastavi",
	"cancelButtonText": "Prekliči"
})

//end v1.x content
);
