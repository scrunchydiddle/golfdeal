//>>built
define(
//begin v1.x content
({
	"save": "Shrani"
})

//end v1.x content
);
