//>>built
define(
//begin v1.x content
({
	insertImageTitle: "Vstavi sliko",
	url: "Slika ",
	browse: "Prebrskaj ... ",
	text: "Opis ",
	set: "Vstavi ",
	invalidMessage: "Neveljavna vrsta slikovne datoteke ",
	prePopuTextUrl: "Vnesite URL slike",
	prePopuTextBrowse: " ali prebrskajte in izberite lokalno datoteko. "
})

//end v1.x content
);
