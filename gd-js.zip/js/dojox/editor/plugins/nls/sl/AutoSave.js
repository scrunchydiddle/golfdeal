//>>built
define(
//begin v1.x content
({
	"saveLabel": "Shrani",
	"saveSettingLabelOn": "Nastavi interval za samodejno shranjevanje ... ",
	"saveSettingLabelOff": "Izključi samodejno shranjevanje ",
	"saveSettingdialogTitle": "Samodejno shranjevanje ",
	"saveSettingdialogDescription": "Podaj interval za samodejno shranjevanje ",
	"saveSettingdialogParamName": "Interval za samodejno shranjevanje ",
	"saveSettingdialogParamLabel": "min",
	"saveSettingdialogButtonOk": "Nastavi interval",
	"saveSettingdialogButtonCancel": "Prekliči",
	"saveMessageSuccess": "Shranjeno ob ${0}",
	"saveMessageFail": "Shranjevanje ob ${0} ni uspelo "
})

//end v1.x content
);
