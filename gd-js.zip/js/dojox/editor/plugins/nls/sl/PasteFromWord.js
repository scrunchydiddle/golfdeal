//>>built
define(
//begin v1.x content
({
	"pasteFromWord": "Prilepi iz programa Word",
	"paste": "Prilepi",
	"cancel": "Prekliči",
	"instructions": "Vsebino iz programa Word prilepite v spodnje besedilno polje.  Ko ste zadovoljni z vstavljeno vsebino, pritisnite gumb Vstavi. Če želite prenehati z vstavljanjem vsebine, pritisnite gumb Prekliči. "
})

//end v1.x content
);
