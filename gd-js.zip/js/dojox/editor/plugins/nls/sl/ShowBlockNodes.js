//>>built
define(
//begin v1.x content
({
	"showBlockNodes": "Pokaži elemente blokade HTML-ja "
})

//end v1.x content
);
