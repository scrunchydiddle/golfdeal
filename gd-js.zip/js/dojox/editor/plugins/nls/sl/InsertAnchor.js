//>>built
define(
//begin v1.x content
({
	insertAnchor: "Vstavi sidro",
	title: "Lastnosti sidra",
	anchor: "Ime:",
	text: "Opis:",
	set: "Nastavi",
	cancel: "Prekliči"
})

//end v1.x content
);
