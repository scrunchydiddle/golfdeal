//>>built
define(
//begin v1.x content
({
	"blockquote": "Bloc de citation"
})

//end v1.x content
);
