//>>built
define(
//begin v1.x content
({
	"save": "Sauvegarder"
})

//end v1.x content
);
