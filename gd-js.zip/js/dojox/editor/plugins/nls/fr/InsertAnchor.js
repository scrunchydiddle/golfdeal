//>>built
define(
//begin v1.x content
({
	insertAnchor: "Insérer un point d'ancrage",
	title: "Propriétés du point d'ancrage",
	anchor: "Nom :",
	text: "Description :",
	set: "Définir",
	cancel: "Annuler"
})

//end v1.x content
);
