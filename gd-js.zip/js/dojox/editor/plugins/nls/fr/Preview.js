//>>built
define(
//begin v1.x content
({
	"preview": "Aperçu"
})

//end v1.x content
);
