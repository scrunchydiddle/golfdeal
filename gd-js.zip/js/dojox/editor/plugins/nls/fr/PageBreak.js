//>>built
define(
//begin v1.x content
({
	"pageBreak": "Saut de page"
})

//end v1.x content
);
