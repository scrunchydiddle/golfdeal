//>>built
define(
//begin v1.x content
({
	insertEntity: "Insertion d'un symbole"
})

//end v1.x content
);
