//>>built
define(
//begin v1.x content
({
	"setButtonText": "Définir",
	"cancelButtonText": "Annuler"
})

//end v1.x content
);
