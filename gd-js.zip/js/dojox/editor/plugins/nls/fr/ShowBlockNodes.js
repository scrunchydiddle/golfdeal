//>>built
define(
//begin v1.x content
({
	"showBlockNodes": "Affichage des éléments de bloc HTML"
})

//end v1.x content
);
