//>>built
define(
//begin v1.x content
({
	"pasteFromWord": "Coller depuis Word",
	"paste": "Coller",
	"cancel": "Annuler",
	"instructions": "Collez le contenu Word dans la zone de texte ci-dessous. Quand le contenu à insérer vous convient, appuyez sur le bouton Coller. Pour annuler l'insertion du texte, utilisez le bouton Annuler."
})

//end v1.x content
);
