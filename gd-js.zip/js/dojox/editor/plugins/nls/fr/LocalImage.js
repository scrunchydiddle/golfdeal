//>>built
define(
//begin v1.x content
({
	insertImageTitle: "Insérer une image",
	url: "Image",
	browse: "Parcourir...",
	text: "Description",
	set: "Insérer",
	invalidMessage: "Type de fichier image non valide",
	prePopuTextUrl: "Entrez une URL d'image",
	prePopuTextBrowse: " ou sélectionnez un fichier local."
})

//end v1.x content
);
