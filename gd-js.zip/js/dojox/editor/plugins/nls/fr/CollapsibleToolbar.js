//>>built
define(
//begin v1.x content
({
	"collapse": "Réduire la barre d'outils de l'éditeur",
	"expand": "Développer la barre d'outils de l'éditeur"
})

//end v1.x content
);
