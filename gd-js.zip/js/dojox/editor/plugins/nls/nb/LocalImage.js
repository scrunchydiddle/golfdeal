//>>built
define(
//begin v1.x content
({
	insertImageTitle: "Sett inn bilde",
	url: "Bilde",
	browse: "Bla gjennom...",
	text: "Beskrivelse",
	set: "Sett inn",
	invalidMessage: "Ugyldig bildefiltype",
	prePopuTextUrl: "Angi en bilde-URL",
	prePopuTextBrowse: " eller bla gjennom til en lokal fil."
})
//end v1.x content
);
