//>>built
define(
//begin v1.x content
({
	"setButtonText": "Definer",
	"cancelButtonText": "Avbryt"
})
//end v1.x content
);
