//>>built
define(
//begin v1.x content
({
	"nodeActions": "${nodeName} Handlinger",
	"selectContents": "Velg innhold",
	"selectElement": "Velg element",
	"deleteElement": "Slett element",
	"deleteContents": "Slett innhold",
	"moveStart": "Flytt markør til start",
	"moveEnd": "Flytt markør til slutt"
})
//end v1.x content
);
