//>>built
define(
//begin v1.x content
({
	insertAnchor: "Sett inn anker",
	title: "Ankeregenskaper",
	anchor: "Navn:",
	text: "Beskrivelse:",
	set: "Definer",
	cancel: "Avbryt"
})
//end v1.x content
);
