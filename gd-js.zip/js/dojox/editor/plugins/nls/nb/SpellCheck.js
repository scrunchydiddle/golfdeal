//>>built
define(
//begin v1.x content
({
	widgetLabel: "Satsvis stavekontroll",
	unfound: "Ikke funnet",
	skip: "Hopp over",
	skipAll: "Hopp over alle",
	toDic: "Legg til i ordliste",
	suggestions: "Forslag",
	replace: "Erstatt",
	replaceWith: "Erstatt med",
	replaceAll: "Erstatt alle",
	cancel: "Avbryt",
	msg: "Ingen stavefeil funnet",
	iSkip: "Hopp over dette",
	iSkipAll: "Hopp over alle slike",
	iMsg: "Ingen staveforslag"
})
//end v1.x content
);
