//>>built
define(
//begin v1.x content
({
	smiley: "Sett inn uttrykksikon",
	emoticonSmile: "smil",
	emoticonLaughing: "latter",
	emoticonWink: "blunk",
	emoticonGrin: "glis",
	emoticonCool: "kul",
	emoticonAngry: "sint",
	emoticonHalf: "halv",
	emoticonEyebrow: "øyebryn",
	emoticonFrown: "streng",
	emoticonShy: "sjenert",
	emoticonGoofy: "tåpelig",
	emoticonOops: "ops",
	emoticonTongue: "tunge",
	emoticonIdea: "ide",
	emoticonYes: "ja",
	emoticonNo: "nei",
	emoticonAngel: "engel",
	emoticonCrying: "gråt"
})
//end v1.x content
);
