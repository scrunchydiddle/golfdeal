//>>built
define(
//begin v1.x content
({
	"pasteFromWord": "Lim inn fra Word",
	"paste": "Lim inn",
	"cancel": "Avbryt",
	"instructions": "Lim inn innhold fra Word til tekstboksen nedenfor. Når du er fornøyd med innholdet du skal sette inn, trykker du på innlimingsknappen. Hvis du vil avbryte innsettingen av teksten, trykker du på avbruddsknappen."
})
//end v1.x content
);
