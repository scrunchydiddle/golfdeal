//>>built
define(
//begin v1.x content
({
	"collapse": "Komprimer verktøylinje for redigeringsprogram",
	"expand": "Utvid verktøylinje for redigeringsprogram"
})
//end v1.x content
);
