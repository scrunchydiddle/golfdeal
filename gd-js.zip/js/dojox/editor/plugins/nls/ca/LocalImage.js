//>>built
define(
//begin v1.x content
({
	insertImageTitle: "Insereix imatge",
	url: "Imatge",
	browse: "Navega...",
	text: "Descripció",
	set: "Insereix",
	invalidMessage: "Tipus de fitxer d\'imatge no vàlid",
	prePopuTextUrl: "Especifiqueu un URL d\'imatge",
	prePopuTextBrowse: " o navegueu fins un fitxer local."
})

//end v1.x content
);
