//>>built
define(
//begin v1.x content
({
	"setButtonText": "Defineix",
	"cancelButtonText": "Cancel·la"
})

//end v1.x content
);
