//>>built
define(
//begin v1.x content
({
	"preview": "Visualització prèvia"
})

//end v1.x content
);
