//>>built
define(
//begin v1.x content
({
	smiley: "Insereix emoticona",
	emoticonSmile: "somriure",
	emoticonLaughing: "rient",
	emoticonWink: "ullet",
	emoticonGrin: "gran somriure",
	emoticonCool: "guai",
	emoticonAngry: "enfadat",
	emoticonHalf: "meitat",
	emoticonEyebrow: "cella",
	emoticonFrown: "espantat",
	emoticonShy: "avergonyit",
	emoticonGoofy: "babau",
	emoticonOops: "ep",
	emoticonTongue: "llengua",
	emoticonIdea: "idea",
	emoticonYes: "sí",
	emoticonNo: "no",
	emoticonAngel: "àngel",
	emoticonCrying: "plorant"
})

//end v1.x content
);
