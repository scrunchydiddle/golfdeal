//>>built
define(
//begin v1.x content
({
	"collapse": "Redueix la barra d'eines de l'editor",
	"expand": "Expandeix la barra d'eines de l'editor"
})

//end v1.x content
);
