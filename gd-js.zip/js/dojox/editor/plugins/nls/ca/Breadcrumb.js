//>>built
define(
//begin v1.x content
({
	"nodeActions": "${nodeName} - Accions",
	"selectContents": "Selecciona contingut",
	"selectElement": "Selecciona element",
	"deleteElement": "Suprimeix element",
	"deleteContents": "Suprimeix contingut",
	"moveStart": "Mou el cursor a l'inici",
	"moveEnd": "Mou el cursor al final"
})

//end v1.x content
);
