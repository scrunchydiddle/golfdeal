//>>built
define(
//begin v1.x content
({
	"pageBreak": "Salt de pàgina"
})

//end v1.x content
);
