//>>built
define(
//begin v1.x content
({
	"showBlockNodes": "Mostra elements de bloc HTML"
})

//end v1.x content
);
