//>>built
define(
//begin v1.x content
({
	insertAnchor: "Insereix una àncora",
	title: "Propietats de l'àncora",
	anchor: "Nom:",
	text: "Descripció:",
	set: "Defineix",
	cancel: "Cancel·la"
})

//end v1.x content
);
