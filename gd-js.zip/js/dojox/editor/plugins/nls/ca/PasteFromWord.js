//>>built
define(
//begin v1.x content
({
	"pasteFromWord": "Enganxa des de Word",
	"paste": "Enganxa",
	"cancel": "Cancel·la",
	"instructions": "Enganxa el contingut de Word al quadre de text següent. Un cop esteu satisfets amb el contingut que voleu inserir, feu clic al botó Enganxa. Per cancel·lar la inserció de text, feu clic al botó Cancel·la."
})

//end v1.x content
);
