//>>built
define(
//begin v1.x content
({
	"save": "Desa"
})

//end v1.x content
);
