//>>built
define(
//begin v1.x content
({
	"nodeActions": "${nodeName} Acties",
	"selectContents": "Inhoud selecteren",
	"selectElement": "Element selecteren",
	"deleteElement": "Element wissen",
	"deleteContents": "Inhoud wissen",
	"moveStart": "Cursor verplaatsen naar start",
	"moveEnd": "Cursor verplaatsen naar eind"
})

//end v1.x content
);
