//>>built
define(
//begin v1.x content
({
	insertAnchor: "Anker invoegen",
	title: "Ankereigenschappen",
	anchor: "Naam:",
	text: "Beschrijving:",
	set: "Instellen",
	cancel: "Annuleren"
})

//end v1.x content
);
