//>>built
define(
//begin v1.x content
({
	insertImageTitle: "Afbeelding invoegen",
	url: "Afbeelding",
	browse: "Bladeren...",
	text: "Beschrijving",
	set: "Invoegen",
	invalidMessage: "Ongeldig bestandstype voor afbeelding",
	prePopuTextUrl: "Geef een afbeeldings-URL op",
	prePopuTextBrowse: " of navigeer naar een lokaal bestand."
})

//end v1.x content
);
