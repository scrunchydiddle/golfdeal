//>>built
define(
//begin v1.x content
({
	"save": "Opslaan"
})

//end v1.x content
);
