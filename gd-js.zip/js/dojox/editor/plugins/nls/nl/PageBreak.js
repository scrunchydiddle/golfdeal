//>>built
define(
//begin v1.x content
({
	"pageBreak": "Paginaeinde"
})

//end v1.x content
);
