//>>built
define(
//begin v1.x content
({
	"showBlockNodes": "HTML-blokelementen afbeelden"
})

//end v1.x content
);
