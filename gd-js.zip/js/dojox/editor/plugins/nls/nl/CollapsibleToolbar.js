//>>built
define(
//begin v1.x content
({
	"collapse": "Editor-werkbalk samenvouwen",
	"expand": "Editor-werkbalk uitvouwen"
})

//end v1.x content
);
