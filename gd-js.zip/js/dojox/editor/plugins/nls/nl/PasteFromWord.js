//>>built
define(
//begin v1.x content
({
	"pasteFromWord": "Plakken vanuit Word",
	"paste": "Plakken",
	"cancel": "Annuleren",
	"instructions": "Plak de content vanuit Word in het tekstvak hieronder. Klik als u klaar bent op de knop Plakken. Kies Annuleren als u de invoeging van tekst wilt afbreken."
})

//end v1.x content
);
