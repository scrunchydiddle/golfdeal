//>>built
define(
//begin v1.x content
({
	smiley: "Wstaw emotikon",
	emoticonSmile: "uśmiech",
	emoticonLaughing: "śmiech",
	emoticonWink: "mrugnięcie",
	emoticonGrin: "szeroki uśmiech",
	emoticonCool: "cwaniak",
	emoticonAngry: "złość",
	emoticonHalf: "niesmak",
	emoticonEyebrow: "uniesienie brwi",
	emoticonFrown: "niezadowolenie",
	emoticonShy: "nieśmiałość",
	emoticonGoofy: "niezdarność",
	emoticonOops: "ups",
	emoticonTongue: "pokazywanie języka",
	emoticonIdea: "pomysł",
	emoticonYes: "Tak",
	emoticonNo: "Nie",
	emoticonAngel: "anioł",
	emoticonCrying: "płacz"
})

//end v1.x content
);
