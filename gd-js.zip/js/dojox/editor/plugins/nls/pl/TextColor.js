//>>built
define(
//begin v1.x content
({
	"setButtonText": "Ustaw",
	"cancelButtonText": "Anuluj"
})

//end v1.x content
);
