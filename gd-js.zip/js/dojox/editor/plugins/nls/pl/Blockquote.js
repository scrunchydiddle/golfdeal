//>>built
define(
//begin v1.x content
({
	"blockquote": "Cytat blokowy"
})

//end v1.x content
);
