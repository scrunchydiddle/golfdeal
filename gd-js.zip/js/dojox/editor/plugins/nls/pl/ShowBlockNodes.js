//>>built
define(
//begin v1.x content
({
	"showBlockNodes": "Pokaż elementy bloków HTML"
})

//end v1.x content
);
