//>>built
define(
//begin v1.x content
({
	"pageBreak": "Podział strony"
})

//end v1.x content
);
