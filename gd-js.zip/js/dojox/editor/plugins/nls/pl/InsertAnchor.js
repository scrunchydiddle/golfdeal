//>>built
define(
//begin v1.x content
({
	insertAnchor: "Wstaw zakotwiczenie",
	title: "Właściwości zakotwiczenia",
	anchor: "Nazwa:",
	text: "Opis:",
	set: "Ustaw",
	cancel: "Anuluj"
})

//end v1.x content
);
