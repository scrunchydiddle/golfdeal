//>>built
define(
//begin v1.x content
({
	"nodeActions": "${nodeName} - działania",
	"selectContents": "Zaznacz treść",
	"selectElement": "Zaznacz element",
	"deleteElement": "Usuń element",
	"deleteContents": "Usuń treść",
	"moveStart": "Przenieś kursor na początek",
	"moveEnd": "Przenieś kursor na koniec"
})

//end v1.x content
);
