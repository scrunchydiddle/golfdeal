//>>built
define(
//begin v1.x content
({
	"pasteFromWord": "Wklej z programu Word",
	"paste": "Wklej",
	"cancel": "Anuluj",
	"instructions": "Wklej tekst z programu Word do poniższego pola tekstowego. Po uzyskaniu odpowiedniej treści do wstawienia kliknij przycisk Wklej. Aby przerwać wstawianie tekstu, kliknij przycisk Anuluj. "
})

//end v1.x content
);
