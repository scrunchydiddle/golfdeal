//>>built
define(
//begin v1.x content
({
	insertImageTitle: "Wstaw obraz",
	url: "Obraz",
	browse: "Przeglądaj...",
	text: "Opis",
	set: "Wstaw",
	invalidMessage: "Niepoprawny typ pliku graficznego",
	prePopuTextUrl: "Wprowadź adres URL obrazu",
	prePopuTextBrowse: " lub wskaż plik lokalny. "
})

//end v1.x content
);
