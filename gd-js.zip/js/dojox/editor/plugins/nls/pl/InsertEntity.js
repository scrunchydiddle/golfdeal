//>>built
define(
//begin v1.x content
({
	insertEntity: "Wstaw symbol"
})

//end v1.x content
);
