//>>built
define(
//begin v1.x content
({
	"collapse": "Zwiń pasek narzędzi edytora",
	"expand": "Rozwiń pasek narzędzi edytora"
})

//end v1.x content
);
