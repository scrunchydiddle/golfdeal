//>>built
define(
//begin v1.x content
({
	"nodeActions": "${nodeName} műveletek",
	"selectContents": "Tartalom kiválasztása",
	"selectElement": "Elem kiválasztása",
	"deleteElement": "Elem törlése",
	"deleteContents": "Tartalom törlése",
	"moveStart": "Kurzor mozgatása az elejére",
	"moveEnd": "Kurzor mozgatása a végére"
})

//end v1.x content
);
