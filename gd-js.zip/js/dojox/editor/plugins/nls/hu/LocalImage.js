//>>built
define(
//begin v1.x content
({
	insertImageTitle: "Kép beszúrása",
	url: "Kép",
	browse: "Tallózás...",
	text: "Leírás",
	set: "Beszúrás",
	invalidMessage: "Érvénytelen képfájltípus",
	prePopuTextUrl: "Adja meg a kép URL címét",
	prePopuTextBrowse: " vagy tallózással válasszon ki egy helyi fájlt."
})

//end v1.x content
);
