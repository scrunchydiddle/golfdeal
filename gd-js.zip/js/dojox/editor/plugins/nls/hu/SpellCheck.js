//>>built
define(
//begin v1.x content
({
	widgetLabel: "Kötegelt helyesírás-ellenőrzés",
	unfound: "Nem található",
	skip: "Kihagyja",
	skipAll: "Mindet kihagyja",
	toDic: "Hozzáadás a szótárhoz",
	suggestions: "Javaslatok",
	replace: "Csere",
	replaceWith: "Csere erre",
	replaceAll: "Mindent lecserél",
	cancel: "Mégse",
	msg: "Nem található helyesírási hiba",
	iSkip: "Ezt kihagyja",
	iSkipAll: "Összes hasonlót kihagyja",
	iMsg: "Nincsenek helyesírási javaslatok"
})

//end v1.x content
);
