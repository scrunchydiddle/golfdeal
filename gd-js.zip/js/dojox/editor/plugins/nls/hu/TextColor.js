//>>built
define(
//begin v1.x content
({
	"setButtonText": "Beállítás",
	"cancelButtonText": "Mégse"
})

//end v1.x content
);
