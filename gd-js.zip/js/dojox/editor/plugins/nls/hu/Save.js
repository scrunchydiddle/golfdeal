//>>built
define(
//begin v1.x content
({
	"save": "Mentés"
})

//end v1.x content
);
