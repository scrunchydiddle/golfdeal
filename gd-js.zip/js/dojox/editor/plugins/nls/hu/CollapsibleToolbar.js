//>>built
define(
//begin v1.x content
({
	"collapse": "Szerkesztő eszköztár összezárása",
	"expand": "Szerkesztő eszköztár kibontása"
})

//end v1.x content
);
