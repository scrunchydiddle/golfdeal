//>>built
define(
//begin v1.x content
({
	"pasteFromWord": "Beillesztés Word alkalmazásból",
	"paste": "Beillesztés",
	"cancel": "Mégse",
	"instructions": "Illessze be a Word alkalmazás tartalmát az alábbi szövegmezőbe. Ha elégedett a beszúrandó tartalommal, akkor nyomja meg a beillesztés gombot. Szöveg beszúrásának megszakításához nyomja meg a mégse gombot."
})

//end v1.x content
);
