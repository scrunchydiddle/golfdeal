//>>built
define(
//begin v1.x content
({
	smiley: "Hangulatjel beszúrása",
	emoticonSmile: "mosoly",
	emoticonLaughing: "nevetés",
	emoticonWink: "kacsintás",
	emoticonGrin: "vigyor",
	emoticonCool: "laza",
	emoticonAngry: "mérges",
	emoticonHalf: "fél",
	emoticonEyebrow: "szemöldök",
	emoticonFrown: "rosszallás",
	emoticonShy: "szégyenlős",
	emoticonGoofy: "ostoba",
	emoticonOops: "hoppá",
	emoticonTongue: "nyelv",
	emoticonIdea: "ötlet",
	emoticonYes: "igen",
	emoticonNo: "nem",
	emoticonAngel: "angyal",
	emoticonCrying: "sírás"
})

//end v1.x content
);
