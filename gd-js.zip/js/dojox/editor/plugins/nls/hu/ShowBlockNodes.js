//>>built
define(
//begin v1.x content
({
	"showBlockNodes": "HTML blokk elemek megjelenítése"
})

//end v1.x content
);
