//>>built
define(
//begin v1.x content
({
	insertAnchor: "Horgony beszúrása",
	title: "Horgony tulajdonságai",
	anchor: "Név:",
	text: "Leírás:",
	set: "Beállítás",
	cancel: "Mégse"
})

//end v1.x content
);
