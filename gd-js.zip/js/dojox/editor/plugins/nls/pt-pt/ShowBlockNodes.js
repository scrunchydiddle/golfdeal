//>>built
define(
//begin v1.x content
({
	"showBlockNodes": "Mostrar elementos do bloco HTML"
})

//end v1.x content
);
