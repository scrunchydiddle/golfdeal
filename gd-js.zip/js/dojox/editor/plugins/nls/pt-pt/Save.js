//>>built
define(
//begin v1.x content
({
	"save": "Guardar"
})

//end v1.x content
);
