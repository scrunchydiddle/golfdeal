//>>built
define(
//begin v1.x content
({
	"preview": "Pré-visualizar"
})

//end v1.x content
);
