//>>built
define(
//begin v1.x content
({
	"pageBreak": "Quebra de página"
})

//end v1.x content
);
