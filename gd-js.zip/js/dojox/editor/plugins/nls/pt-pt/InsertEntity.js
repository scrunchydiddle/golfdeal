//>>built
define(
//begin v1.x content
({
	insertEntity: "Inserir símbolo"
})

//end v1.x content
);
