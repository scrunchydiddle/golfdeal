//>>built
define(
//begin v1.x content
({
	"collapse": "Contrair barra de ferramentas do editor",
	"expand": "Expandir barra de ferramentas do editor"
})

//end v1.x content
);
