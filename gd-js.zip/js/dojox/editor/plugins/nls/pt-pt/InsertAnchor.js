//>>built
define(
//begin v1.x content
({
	insertAnchor: "Inserir âncora",
	title: "Propriedades da âncora",
	anchor: "Nome:",
	text: "Descrição:",
	set: "Definir",
	cancel: "Cancelar"
})

//end v1.x content
);
