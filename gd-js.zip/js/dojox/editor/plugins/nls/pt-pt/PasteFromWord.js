//>>built
define(
//begin v1.x content
({
	"pasteFromWord": "Colar do Word",
	"paste": "Colar",
	"cancel": "Cancelar",
	"instructions": "Cole o conteúdo do Word na caixa de texto abaixo. Após estar satisfeito com o conteúdo a inserir, prima o botão de colagem. Para cancelar a inserção de texto, prima o botão de cancelamento."
})

//end v1.x content
);
