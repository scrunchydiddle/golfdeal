//>>built
define(
//begin v1.x content
({
	"showBlockNodes": "عرض عناصر كتلة HTML"
})

//end v1.x content
);
