//>>built
define(
//begin v1.x content
({
	"pageBreak": "فاصل الصفحات"
})

//end v1.x content
);
