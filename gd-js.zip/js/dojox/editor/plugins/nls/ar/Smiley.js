//>>built
define(
//begin v1.x content
({
	smiley: "ادراج شكل متحرك",
	emoticonSmile: "ابتسامة",
	emoticonLaughing: "ضاحك",
	emoticonWink: "غمزة",
	emoticonGrin: "تكشير",
	emoticonCool: "حسنا",
	emoticonAngry: "غضبان",
	emoticonHalf: "نصف",
	emoticonEyebrow: "حاجب",
	emoticonFrown: "عبوس",
	emoticonShy: "خجول",
	emoticonGoofy: "أبله",
	emoticonOops: "عفوا",
	emoticonTongue: "لسان",
	emoticonIdea: "فكرة",
	emoticonYes: "نعم",
	emoticonNo: "لا",
	emoticonAngel: "ملاك",
	emoticonCrying: "يبكي"
})

//end v1.x content
);
