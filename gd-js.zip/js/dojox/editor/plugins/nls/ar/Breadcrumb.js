//>>built
define(
//begin v1.x content
({
	"nodeActions": "${nodeName} تصرفات",
	"selectContents": "تحديد المحتويات",
	"selectElement": "تحديد عنصر",
	"deleteElement": "حذف عنصر",
	"deleteContents": "حذف محتويات",
	"moveStart": "نقل المؤشر للبداية",
	"moveEnd": "نقل المؤشر للنهاية"
})

//end v1.x content
);
