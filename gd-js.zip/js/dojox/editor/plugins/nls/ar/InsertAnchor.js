//>>built
define(
//begin v1.x content
({
	insertAnchor: "ادراج نقطة التثبيت",
	title: "خصائص نقطة التثبيت",
	anchor: "الاسم:",
	text: "الوصف:",
	set: "تحديد",
	cancel: "الغاء"
})

//end v1.x content
);
