//>>built
define(
//begin v1.x content
({
	"setButtonText": "تحديد",
	"cancelButtonText": "الغاء"
})

//end v1.x content
);
