//>>built
define(
//begin v1.x content
({
	"collapse": "طي خط أدوات المحرر",
	"expand": "توسيع خط أدوات المحرر"
})

//end v1.x content
);
