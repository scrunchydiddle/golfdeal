//>>built
define(
//begin v1.x content
({
	insertImageTitle: "ادراج صورة",
	url: "صورة",
	browse: "استعراض...",
	text: "الوصف",
	set: "‏ادراج‏",
	invalidMessage: "نوع ملف صور غير صحيح",
	prePopuTextUrl: "ادخل عنوان URL لصورة",
	prePopuTextBrowse: " أو تصفح الى ملف محلي."
})

//end v1.x content
);
