//>>built
define(
//begin v1.x content
({
	"blockquote": "علامة تنصيص الفقرة"
})

//end v1.x content
);
