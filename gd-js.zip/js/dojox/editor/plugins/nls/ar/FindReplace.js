//>>built
define(
//begin v1.x content
({
	"findLabel": "ايجاد:",
	"findTooltip": "ادخال نص لايجاد",
	"replaceLabel": "استبدال بالآتي:",
	"replaceTooltip": "ادخال نص للاستبدال مع",
	"findReplace": "ايجاد واستبدال",
	"matchCase": "مطابقة حالة الحروف",
	"matchCaseTooltip": "مطابقة حالة الحروف",
	"backwards": "الى الوراء",
	"backwardsTooltip": "البحث الى الوراء عن نص",
	"replaceAll": "كل التكرارات",
	"replaceAllButton": "استبدال كل",
	"replaceAllButtonTooltip": "استبدال كل النص",
	"findButton": "ايجاد",
	"findButtonTooltip": "ايجاد النص",
	"replaceButton": "استبدال",
	"replaceButtonTooltip": "استبدال النص",
	"replaceDialogText": "التكرارات ${0} المستبدلة.",
	"eofDialogText": "آخر تكرار ${0}",
	"eofDialogTextFind": "موجودة",
	"eofDialogTextReplace": "مستبدل"
})

//end v1.x content
);
