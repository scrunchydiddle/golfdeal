//>>built
define(
//begin v1.x content
({
	"pasteFromWord": "لصق من Word",
	"paste": "لصق",
	"cancel": "الغاء",
	"instructions": "لصق المحتويات من Word الى مربع النص بأسفل. بمجرد أن تكون راضيا عن المحتوى المراد ادراجه، اضغط على اختيار لصق. للتوقف عن ادراج النص، اضغط  اختيار الغاء."
})

//end v1.x content
);
