//>>built
define(
//begin v1.x content
({
	"collapse": "Свернуть панель редактирования",
	"expand": "Развернуть панель редактирования"
})

//end v1.x content
);
