//>>built
define(
//begin v1.x content
({
	insertImageTitle: "Вставить изображение",
	url: "Изображение",
	browse: "Обзор...",
	text: "Описание",
	set: "Вставить",
	invalidMessage: "Недопустимый тип файла изображения",
	prePopuTextUrl: "Введите URL изображения",
	prePopuTextBrowse: " или выберите локальный файл."
})

//end v1.x content
);
