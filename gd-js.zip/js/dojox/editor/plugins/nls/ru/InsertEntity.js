//>>built
define(
//begin v1.x content
({
	insertEntity: "Вставить символ"
})

//end v1.x content
);
