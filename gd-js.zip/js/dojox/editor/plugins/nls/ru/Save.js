//>>built
define(
//begin v1.x content
({
	"save": "Сохранить"
})

//end v1.x content
);
