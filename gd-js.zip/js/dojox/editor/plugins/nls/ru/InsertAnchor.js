//>>built
define(
//begin v1.x content
({
	insertAnchor: "Вставить метку",
	title: "Свойства метки",
	anchor: "Имя:",
	text: "Описание:",
	set: "Задать",
	cancel: "Отменить"
})

//end v1.x content
);
