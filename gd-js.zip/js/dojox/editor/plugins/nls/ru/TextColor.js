//>>built
define(
//begin v1.x content
({
	"setButtonText": "Задать",
	"cancelButtonText": "Отменить"
})

//end v1.x content
);
