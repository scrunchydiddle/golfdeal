//>>built
define(
//begin v1.x content
({
	"pageBreak": "Разделитель страниц"
})

//end v1.x content
);
