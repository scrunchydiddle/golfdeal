//>>built
define(
//begin v1.x content
({
	"showBlockNodes": "Показать элементы блока HTML"
})

//end v1.x content
);
