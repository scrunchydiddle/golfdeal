//>>built
define(
//begin v1.x content
({
	"pasteFromWord": "Word'den Kopyala",
	"paste": "Yapıştır",
	"cancel": "İptal",
	"instructions": "İçeriği Word'den aşağıdaki metin kutusuna yapıştırın. Eklediğiniz içerikten memnunsanız, Yapıştır düğmesini tıklatın. Metin eklemeyi durdurmak için İptal düğmesini tıklatın."
})

//end v1.x content
);
