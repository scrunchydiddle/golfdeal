//>>built
define(
//begin v1.x content
({
	insertEntity: "Simge Ekle"
})

//end v1.x content
);
