//>>built
define(
//begin v1.x content
({
	"collapse": "Düzenleyici Araç Çubuğunu Daralt",
	"expand": "Düzenleyici Araç Çubuğunu Genişlet"
})

//end v1.x content
);
