//>>built
define(
//begin v1.x content
({
	"pageBreak": "Sayfa Sonu"
})

//end v1.x content
);
