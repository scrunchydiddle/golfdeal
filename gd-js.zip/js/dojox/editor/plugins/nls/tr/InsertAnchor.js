//>>built
define(
//begin v1.x content
({
	insertAnchor: "Tutturucu Ekle",
	title: "Tutturucu Özellikleri",
	anchor: "Ad:",
	text: "Açıklama:",
	set: "Ayarla",
	cancel: "İptal"
})

//end v1.x content
);
