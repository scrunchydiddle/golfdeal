//>>built
define(
//begin v1.x content
({
	smiley: "İfade Ekle",
	emoticonSmile: "gülümseme",
	emoticonLaughing: "kahkaha",
	emoticonWink: "göz kırpma",
	emoticonGrin: "sırıtma",
	emoticonCool: "havalı",
	emoticonAngry: "kızgın",
	emoticonHalf: "kafası karışık ifade",
	emoticonEyebrow: "kaşı kalkık ifade",
	emoticonFrown: "kaşı çatık ifade",
	emoticonShy: "utangaç",
	emoticonGoofy: "ağzı açık ifade",
	emoticonOops: "şaşıran ifade",
	emoticonTongue: "dil çıkaran ifade",
	emoticonIdea: "aklına bir fikir gelmiş",
	emoticonYes: "evet",
	emoticonNo: "hayır",
	emoticonAngel: "melek",
	emoticonCrying: "ağlayan ifade"
})

//end v1.x content
);
