//>>built
define(
//begin v1.x content
({
	"nodeActions": "${nodeName} Eylemleri",
	"selectContents": "İçindekileri seç",
	"selectElement": "Öğeyi seç",
	"deleteElement": "Öğeyi sil",
	"deleteContents": "İçindekileri sil",
	"moveStart": "İmleci başa taşı",
	"moveEnd": "İmleci sona taşı"
})

//end v1.x content
);
