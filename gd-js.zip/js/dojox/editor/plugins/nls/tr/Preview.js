//>>built
define(
//begin v1.x content
({
	"preview": "Önizleme"
})

//end v1.x content
);
