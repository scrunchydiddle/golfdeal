//>>built
define(
//begin v1.x content
({
	"showBlockNodes": "HTML Bloğu Öğelerini Göster"
})

//end v1.x content
);
