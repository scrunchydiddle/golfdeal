//>>built
define(
//begin v1.x content
({
	"collapse": "Өңдегіш құралдар тақтасын тасалау",
	"expand": "Өңдегіш құралдар тақтасын шығарып алу"
})

//end v1.x content
);
