//>>built
define(
//begin v1.x content
({
	"setButtonText": "Орнату",
	"cancelButtonText": "Болдырмау"
})

//end v1.x content
);
