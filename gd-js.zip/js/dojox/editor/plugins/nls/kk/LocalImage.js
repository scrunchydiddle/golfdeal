//>>built
define(
//begin v1.x content
({
	insertImageTitle: "Сурет кірістіру",
	url: "Кескін",
	browse: "Шолу...",
	text: "Сипаттама",
	set: "Кірістіру",
	invalidMessage: "Кескін файлының түрі дұрыс емес",
	prePopuTextUrl: "Кескіннің URL мекен-жайын енгізіңіз",
	prePopuTextBrowse: " немесе жергілікті файлға өтіңіз."
})

//end v1.x content
);
