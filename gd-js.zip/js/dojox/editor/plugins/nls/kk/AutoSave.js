//>>built
define(
//begin v1.x content
({
	"saveLabel": "Сақтау",
	"saveSettingLabelOn": "Автосақтау аралығын орнату...",
	"saveSettingLabelOff": "Автосақтауды өшіру",
	"saveSettingdialogTitle": "Автосақтау",
	"saveSettingdialogDescription": "Автосақтау аралығын көрсету",
	"saveSettingdialogParamName": "Автосақтау аралығы",
	"saveSettingdialogParamLabel": "мин",
	"saveSettingdialogButtonOk": "Аралықты орнату",
	"saveSettingdialogButtonCancel": "Болдырмау",
	"saveMessageSuccess": "${0} сақталды",
	"saveMessageFail": "${0} сақталмады"
})

//end v1.x content
);
