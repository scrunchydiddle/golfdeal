//>>built
define(
//begin v1.x content
({
	smiley: "Эмограмма енгізу",
	emoticonSmile: "күлімсіреу",
	emoticonLaughing: "күлу",
	emoticonWink: "көз қысу",
	emoticonGrin: "ақситу",
	emoticonCool: "салқын",
	emoticonAngry: "ашулы",
	emoticonHalf: "жарты",
	emoticonEyebrow: "қас",
	emoticonFrown: "қабағы түйілу",
	emoticonShy: "ұялшақ",
	emoticonGoofy: "ақымақ",
	emoticonOops: "ой",
	emoticonTongue: "тіл",
	emoticonIdea: "ой",
	emoticonYes: "иә",
	emoticonNo: "ешбір",
	emoticonAngel: "періште",
	emoticonCrying: "жылау"
})

//end v1.x content
);
