//>>built
define(
//begin v1.x content
({
	"pageBreak": "Бет үзілімі"
})

//end v1.x content
);
