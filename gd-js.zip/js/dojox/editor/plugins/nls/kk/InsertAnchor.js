//>>built
define(
//begin v1.x content
({
	insertAnchor: "Бетбелгі кірістіру",
	title: "Бетбелгі сипаттары",
	anchor: "Аты:",
	text: "Сипаттама:",
	set: "Орнату",
	cancel: "Болдырмау"
})

//end v1.x content
);
