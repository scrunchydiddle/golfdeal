//>>built
define(
//begin v1.x content
({
	widgetLabel: "Бума емлесін тексеру",
	unfound: "Табылмады",
	skip: "Өткізіп жіберу",
	skipAll: "Барлығын өткізіп жіберу",
	toDic: "Сөздікке қосу",
	suggestions: "Ұсыныстар",
	replace: "Ауыстыру",
	replaceWith: "Келесімен ауыстыру",
	replaceAll: "Барлығын ауыстыру",
	cancel: "Болдырмау",
	msg: "Қате жазылған сөздер табылмады",
	iSkip: "Бұны өткізіп жіберу",
	iSkipAll: "Осы сияқты барлығын өткізіп жіберу",
	iMsg: "Емле ұсыныстары жоқ"
})

//end v1.x content
);
