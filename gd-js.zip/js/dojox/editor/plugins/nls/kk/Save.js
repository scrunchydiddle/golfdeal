//>>built
define(
//begin v1.x content
({
	"save": "Сақтау"
})

//end v1.x content
);
