//>>built
define(
//begin v1.x content
({
	"nodeActions": "${nodeName} Әрекеттер",
	"selectContents": "Мазмұнын таңдау",
	"selectElement": "Элементті таңдау",
	"deleteElement": "Элементті жою",
	"deleteContents": "Мазмұнын жою",
	"moveStart": "Жүгіргіні басына жылжыту",
	"moveEnd": "Жүгіргіні аяғына жылжыту"
})

//end v1.x content
);
