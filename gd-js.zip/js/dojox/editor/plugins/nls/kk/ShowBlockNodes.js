//>>built
define(
//begin v1.x content
({
	"showBlockNodes": "HTML блогы элементтерін көрсету"
})

//end v1.x content
);
