//>>built
define(
//begin v1.x content
({
	insertEntity: "Нышанды кірістіру"
})

//end v1.x content
);
