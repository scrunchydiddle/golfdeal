//>>built
define(
//begin v1.x content
({
	"save": "Tallenna"
})

//end v1.x content
);
