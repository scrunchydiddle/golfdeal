//>>built
define(
//begin v1.x content
({
	"setButtonText": "Aseta",
	"cancelButtonText": "Peruuta"
})

//end v1.x content
);
