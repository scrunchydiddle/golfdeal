//>>built
define(
//begin v1.x content
({
	insertImageTitle: "Lisää kuva",
	url: "Kuva",
	browse: "Selaa...",
	text: "Kuvaus",
	set: "Lisää",
	invalidMessage: "Virheellinen kuvatiedoston laji",
	prePopuTextUrl: "Anna kuvan URL-osoite",
	prePopuTextBrowse: " tai selaa paikalliseen tiedostoon."
})

//end v1.x content
);
