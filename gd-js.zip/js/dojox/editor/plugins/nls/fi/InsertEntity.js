//>>built
define(
//begin v1.x content
({
	insertEntity: "Lisää symboli"
})

//end v1.x content
);
