//>>built
define(
//begin v1.x content
({
	"showBlockNodes": "Näytä HTML-lohkoelementit"
})

//end v1.x content
);
