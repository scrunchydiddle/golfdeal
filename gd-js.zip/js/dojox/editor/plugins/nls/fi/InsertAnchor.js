//>>built
define(
//begin v1.x content
({
	insertAnchor: "Lisää ankkuri",
	title: "Ankkurin ominaisuudet",
	anchor: "Nimi:",
	text: "Kuvaus:",
	set: "Aseta",
	cancel: "Peruuta"
})

//end v1.x content
);
