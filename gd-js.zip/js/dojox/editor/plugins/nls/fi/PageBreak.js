//>>built
define(
//begin v1.x content
({
	"pageBreak": "Sivunvaihto"
})

//end v1.x content
);
