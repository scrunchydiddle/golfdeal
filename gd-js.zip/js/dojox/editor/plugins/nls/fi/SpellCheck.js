//>>built
define(
//begin v1.x content
({
	widgetLabel: "Eräoikoluku",
	unfound: "Ei löydy",
	skip: "Ohita",
	skipAll: "Ohita kaikki",
	toDic: "Lisää sanastoon",
	suggestions: "Ehdotukset",
	replace: "Korvaa",
	replaceWith: "Korvaava",
	replaceAll: "Korvaa kaikki",
	cancel: "Peruuta",
	msg: "Kirjoitusvirheitä ei löytynyt",
	iSkip: "Ohita tämä",
	iSkipAll: "Ohita kaikki samanlaiset",
	iMsg: "Ei oikeinkirjoitusehdotuksia"
})

//end v1.x content
);
