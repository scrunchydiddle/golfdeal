//>>built
define(
//begin v1.x content
({
	"saveLabel": "Tallenna",
	"saveSettingLabelOn": "Aseta automaattisen tallennuksen väli...",
	"saveSettingLabelOff": "Ota automaattinen tallennus pois käytöstä",
	"saveSettingdialogTitle": "Automaattinen tallennus",
	"saveSettingdialogDescription": "Määritä automaattisen tallennuksen väli",
	"saveSettingdialogParamName": "Automaattisen tallennuksen väli",
	"saveSettingdialogParamLabel": "min",
	"saveSettingdialogButtonOk": "Aseta väli",
	"saveSettingdialogButtonCancel": "Peruuta",
	"saveMessageSuccess": "Tallennusaika ${0}",
	"saveMessageFail": "Tallennus epäonnistui ${0}"
})

//end v1.x content
);
