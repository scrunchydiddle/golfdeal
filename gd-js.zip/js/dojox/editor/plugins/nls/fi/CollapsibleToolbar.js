//>>built
define(
//begin v1.x content
({
	"collapse": "Pienennä muokkausohjelman työkalurivi",
	"expand": "Laajenna muokkausohjelman työkalurivi"
})

//end v1.x content
);
