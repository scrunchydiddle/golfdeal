//>>built
define(
//begin v1.x content
({
	"pasteFromWord": "Liitä Word-ohjelmasta",
	"paste": "Liitä",
	"cancel": "Peruuta",
	"instructions": "Liitä sisältö Word-tiedostosta alla olevaan tekstikenttään. Kun lisättävä sisältö on mielestäsi valmis, napsauta Liitä-painiketta. Voit peruuttaa lisäyksen napsauttamalla Peruuta-painiketta."
})

//end v1.x content
);
