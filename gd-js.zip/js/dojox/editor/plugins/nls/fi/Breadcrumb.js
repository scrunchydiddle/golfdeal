//>>built
define(
//begin v1.x content
({
	"nodeActions": "${nodeName} - Toiminnot",
	"selectContents": "Valitse sisältö",
	"selectElement": "Valitse elementti",
	"deleteElement": "Poista elementti",
	"deleteContents": "Poista sisältö",
	"moveStart": "Siirrä kohdistin alkuun",
	"moveEnd": "Siirrä kohdistin loppuun"
})

//end v1.x content
);
