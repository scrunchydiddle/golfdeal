//>>built
define(
//begin v1.x content
({
	widgetLabel: "Συνολικός ορθογραφικός έλεγχος",
	unfound: "Δεν εντοπίστηκε",
	skip: "Παράλειψη",
	skipAll: "Παράλειψη όλων",
	toDic: "Προσθήκη στο λεξικό",
	suggestions: "Προτάσεις",
	replace: "Αντικατάσταση",
	replaceWith: "Αντικατάσταση με",
	replaceAll: "Αντικατάσταση όλων",
	cancel: "Ακύρωση",
	msg: "Δεν βρέθηκαν ορθογραφικά λάθη",
	iSkip: "Παράλειψη τρέχοντος",
	iSkipAll: "Παράλειψη όλων των όμοιων",
	iMsg: "Δεν υπάρχουν προτάσεις ορθογραφίας"
})

//end v1.x content
);
