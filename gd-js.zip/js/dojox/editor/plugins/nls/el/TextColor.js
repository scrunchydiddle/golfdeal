//>>built
define(
//begin v1.x content
({
	"setButtonText": "Ορισμός",
	"cancelButtonText": "Ακύρωση"
})

//end v1.x content
);
