//>>built
define(
//begin v1.x content
({
	"showBlockNodes": "Εμφάνιση στοιχείων ενότητας HTML"
})

//end v1.x content
);
