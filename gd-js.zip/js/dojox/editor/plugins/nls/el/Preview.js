//>>built
define(
//begin v1.x content
({
	"preview": "Προεπισκόπηση"
})

//end v1.x content
);
