//>>built
define(
//begin v1.x content
({
	smiley: "Εισαγωγή εικονιδίου συναισθήματος",
	emoticonSmile: "Χαμόγελο",
	emoticonLaughing: "Γέλιο",
	emoticonWink: "Κλείσιμο ματιού",
	emoticonGrin: "Πλατύ χαμόγελο",
	emoticonCool: "Άνετος",
	emoticonAngry: "Θυμωμένος",
	emoticonHalf: "Μισό",
	emoticonEyebrow: "Σηκωμένο φρύδι",
	emoticonFrown: "Συνοφρυωμένος",
	emoticonShy: "Ντροπαλός",
	emoticonGoofy: "Χαζόφατσα",
	emoticonOops: "Έκπληξη",
	emoticonTongue: "Κοροϊδία",
	emoticonIdea: "Ιδέα",
	emoticonYes: "Ναι",
	emoticonNo: "Όχι",
	emoticonAngel: "Αγγελούδι",
	emoticonCrying: "Κλάμα"
})

//end v1.x content
);
