//>>built
define(
//begin v1.x content
({
	insertAnchor: "Εισαγωγή αγκίστρωσης",
	title: "Ιδιότητες αγκίστρωσης",
	anchor: "Όνομα:",
	text: "Περιγραφή:",
	set: "Ορισμός",
	cancel: "Ακύρωση"
})

//end v1.x content
);
