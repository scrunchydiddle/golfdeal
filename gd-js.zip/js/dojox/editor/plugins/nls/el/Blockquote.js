//>>built
define(
//begin v1.x content
({
	"blockquote": "Ενότητα παράθεσης"
})

//end v1.x content
);
