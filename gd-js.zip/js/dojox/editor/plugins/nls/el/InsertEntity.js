//>>built
define(
//begin v1.x content
({
	insertEntity: "Εισαγωγή συμβόλου"
})

//end v1.x content
);
