//>>built
define(
//begin v1.x content
({
	insertAnchor: "Inserir Âncora",
	title: "Propriedades de Âncora",
	anchor: "Nome:",
	text: "Descrição:",
	set: "Definir",
	cancel: "Cancelar"
})
//end v1.x content
);
