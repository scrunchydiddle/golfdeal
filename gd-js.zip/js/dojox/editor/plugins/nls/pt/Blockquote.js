//>>built
define(
//begin v1.x content
({
	"blockquote": "Citação de Bloco"
})
//end v1.x content
);
