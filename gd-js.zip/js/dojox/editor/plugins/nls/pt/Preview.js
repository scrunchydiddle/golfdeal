//>>built
define(
//begin v1.x content
({
	"preview": "Visualização"
})

//end v1.x content
);
