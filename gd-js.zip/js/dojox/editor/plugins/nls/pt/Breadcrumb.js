//>>built
define(
//begin v1.x content
({
	"nodeActions": "${nodeName} Ações",
	"selectContents": "Selecionar Conteúdo",
	"selectElement": "Selecionar Elemento",
	"deleteElement": "Excluir Elemento",
	"deleteContents": "Excluir Conteúdo",
	"moveStart": "Mover Cursor para o Início",
	"moveEnd": "Mover Cursor para o Final"
})

//end v1.x content
);
