//>>built
define(
//begin v1.x content
({
	"setButtonText": "Definir",
	"cancelButtonText": "Cancelar"
})
//end v1.x content
);
