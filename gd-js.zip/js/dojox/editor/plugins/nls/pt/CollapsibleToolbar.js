//>>built
define(
//begin v1.x content
({
	"collapse": "Reduzir Barra de Ferramentas do Editor",
	"expand": "Expandir Barra de Ferramentas do Editor"
})
//end v1.x content
);
