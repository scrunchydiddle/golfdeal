//>>built
define(
//begin v1.x content
({
	"pageBreak": "Quebra de Página"
})

//end v1.x content
);
