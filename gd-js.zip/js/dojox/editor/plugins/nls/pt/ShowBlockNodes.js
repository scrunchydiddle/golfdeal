//>>built
define(
//begin v1.x content
({
	"showBlockNodes": "Mostrar Elementos de Bloco HTML"
})

//end v1.x content
);
