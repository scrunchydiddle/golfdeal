//>>built
define(
//begin v1.x content
({
	"pasteFromWord": "Colar do Word",
	"paste": "Colar",
	"cancel": "Cancelar",
	"instructions": "Cole o conteúdo do Word na caixa de texto a seguir. Quando estiver satisfeito com o conteúdo a ser inserido, pressione o botão para colar. Para interromper a inserção de texto, pressione o botão para cancelar."
})
//end v1.x content
);
