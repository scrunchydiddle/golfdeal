//>>built
define(
//begin v1.x content
({
	"collapse": "Zvinúť lištu nástrojov editora",
	"expand": "Rozvinúť lištu nástrojov editora"
})

//end v1.x content
);
