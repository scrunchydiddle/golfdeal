//>>built
define(
//begin v1.x content
({
	smiley: "Vložiť emotikon",
	emoticonSmile: "úsmev",
	emoticonLaughing: "smiech",
	emoticonWink: "žmurknutie",
	emoticonGrin: "úškľabok",
	emoticonCool: "super",
	emoticonAngry: "nahnevaný",
	emoticonHalf: "polovica",
	emoticonEyebrow: "zdvihnuté obočie",
	emoticonFrown: "zamračený",
	emoticonShy: "hanblivý",
	emoticonGoofy: "pojašený",
	emoticonOops: "ups",
	emoticonTongue: "jazyk",
	emoticonIdea: "nápad",
	emoticonYes: "áno",
	emoticonNo: "nie",
	emoticonAngel: "anjel",
	emoticonCrying: "plač"
})

//end v1.x content
);
