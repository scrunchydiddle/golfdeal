//>>built
define(
//begin v1.x content
({
	"save": "Uložiť"
})

//end v1.x content
);
