//>>built
define(
//begin v1.x content
({
	"nodeActions": "Akcie pre ${nodeName}",
	"selectContents": "Vybrať obsah",
	"selectElement": "Vybrať element",
	"deleteElement": "Vymazať element",
	"deleteContents": "Vymazať obsah",
	"moveStart": "Presunúť kurzor na začiatok",
	"moveEnd": "Presunúť kurzor na koniec"
})

//end v1.x content
);
