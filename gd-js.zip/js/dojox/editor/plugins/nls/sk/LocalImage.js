//>>built
define(
//begin v1.x content
({
	insertImageTitle: "Vložiť obrázok",
	url: "Obrázok",
	browse: "Prehľadať...",
	text: "Opis",
	set: "Vložiť",
	invalidMessage: "Neplatný typ súboru obrázka",
	prePopuTextUrl: "Zadajte adresu URL",
	prePopuTextBrowse: "alebo nájdite lokálny súbor."
})

//end v1.x content
);
