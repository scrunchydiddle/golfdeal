//>>built
define(
//begin v1.x content
({
	"pasteFromWord": "Prilepiť z aplikácie Word",
	"paste": "Prilepiť",
	"cancel": "Zrušiť",
	"instructions": "Prilepte obsah z aplikácie Word do textového okienka dole. Keď ste spokojný s obsahom na vloženie, stlačte tlačidlo prilepenia. Ak chcete zrušiť vkladanie textu, stlačte tlačidlo zrušenia."
})

//end v1.x content
);
