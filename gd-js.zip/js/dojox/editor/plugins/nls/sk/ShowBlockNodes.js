//>>built
define(
//begin v1.x content
({
	"showBlockNodes": "Zobraziť elementy blokov HTML"
})

//end v1.x content
);
