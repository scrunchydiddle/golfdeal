//>>built
define(
//begin v1.x content
({
	insertEntity: "Vložiť symbol"
})

//end v1.x content
);
