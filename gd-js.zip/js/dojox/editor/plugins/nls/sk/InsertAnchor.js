//>>built
define(
//begin v1.x content
({
	insertAnchor: "Vložiť kotvu",
	title: "Vlastnosti kotvy",
	anchor: "Názov:",
	text: "Opis:",
	set: "Nastaviť",
	cancel: "Zrušiť"
})

//end v1.x content
);
