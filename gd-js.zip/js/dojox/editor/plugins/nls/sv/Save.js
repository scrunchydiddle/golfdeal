//>>built
define(
//begin v1.x content
({
	"save": "Spara"
})

//end v1.x content
);
