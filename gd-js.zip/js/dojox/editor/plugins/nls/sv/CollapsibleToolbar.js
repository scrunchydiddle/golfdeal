//>>built
define(
//begin v1.x content
({
	"collapse": "Komprimera redigerarverktygsfältet",
	"expand": "Expandera redigerarverktygsfältet"
})

//end v1.x content
);
