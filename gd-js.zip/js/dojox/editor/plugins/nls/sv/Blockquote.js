//>>built
define(
//begin v1.x content
({
	"blockquote": "Blockcitat"
})

//end v1.x content
);
