//>>built
define(
//begin v1.x content
({
	insertImageTitle: "Infoga bild",
	url: "Bild",
	browse: "Bläddra...",
	text: "Beskrivning",
	set: "Infoga",
	invalidMessage: "Ogiltigt bildfilformat",
	prePopuTextUrl: "Ange en bild-URL-adress",
	prePopuTextBrowse: " eller bläddra efter en lokal fil."
})

//end v1.x content
);
