//>>built
define(
//begin v1.x content
({
	widgetLabel: "Verificare ortografică lot",
	unfound: "Nu a fost găsit",
	skip: "Salt",
	skipAll: "Salt toate",
	toDic: "Adăugare la dicţionar",
	suggestions: "Sugestii",
	replace: "Înlocuire",
	replaceWith: "Înlocuire cu",
	replaceAll: "Înlocuire toate",
	cancel: "Anulare",
	msg: "Nicio greşeală de verificare ortografică nu a fost găsită.",
	iSkip: "Salt peste acesta",
	iSkipAll: "Salt peste toate acestea",
	iMsg: "Nicio sugestie de verificare ortografică"
})

//end v1.x content
);
