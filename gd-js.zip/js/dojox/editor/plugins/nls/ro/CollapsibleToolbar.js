//>>built
define(
//begin v1.x content
({
	"collapse": "Restrângere bară de unelte Editor",
	"expand": "Expandare bară de unelte Editor"
})

//end v1.x content
);
