//>>built
define(
//begin v1.x content
({
	"pasteFromWord": "Lipire din Word",
	"paste": "Lipire",
	"cancel": "Anulare",
	"instructions": "Lipiţi conţinut din Word în caeta de text de mai jos. După ce sunteţi mulţumit de conţinutul de inserat, apăsaţi butonul Lipire. Pentru a renunţa la inserarea textului, apăsaţi butonul Anulare."
})

//end v1.x content
);
