//>>built
define(
//begin v1.x content
({
	insertImageTitle: "Inserare imagine",
	url: "Imagine",
	browse: "Răsfoire...",
	text: "Descriere",
	set: "Inserare",
	invalidMessage: "Tip de fişier imagine nevalid",
	prePopuTextUrl: "Introduceţi un URL de imagine",
	prePopuTextBrowse: "sau răsfoiţi la un fişier local."
})

//end v1.x content
);
