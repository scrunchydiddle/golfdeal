//>>built
define(
//begin v1.x content
({
	insertEntity: "Inserare simbol"
})

//end v1.x content
);
