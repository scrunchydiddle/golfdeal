//>>built
define(
//begin v1.x content
({
	smiley: "Inserare emoticoane",
	emoticonSmile: "zâmbet",
	emoticonLaughing: "râs",
	emoticonWink: "face cu ochiul",
	emoticonGrin: "rânjet",
	emoticonCool: "calm",
	emoticonAngry: "furios",
	emoticonHalf: "jumătate",
	emoticonEyebrow: "sprânceană",
	emoticonFrown: "posac",
	emoticonShy: "timid",
	emoticonGoofy: "tont",
	emoticonOops: "vai",
	emoticonTongue: "limbă",
	emoticonIdea: "idee",
	emoticonYes: "da",
	emoticonNo: "nu",
	emoticonAngel: "înger",
	emoticonCrying: "plâns"
})

//end v1.x content
);
