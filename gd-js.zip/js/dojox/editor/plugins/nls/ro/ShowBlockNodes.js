//>>built
define(
//begin v1.x content
({
	"showBlockNodes": "Afişare bloc elemente HTML"
})

//end v1.x content
);
