//>>built
define(
//begin v1.x content
({
	insertAnchor: "Inserare ancoră",
	title: "Proprietăţi ancoră",
	anchor: "Nume:",
	text: "Descriere:",
	set: "Setare",
	cancel: "Anulare"
})

//end v1.x content
);
