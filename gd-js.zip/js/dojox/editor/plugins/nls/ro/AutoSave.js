//>>built
define(
//begin v1.x content
({
	"saveLabel": "Salvare",
	"saveSettingLabelOn": "Setare interval auto-salvare...",
	"saveSettingLabelOff": "Oprire auto-salvare",
	"saveSettingdialogTitle": "Auto-salvare",
	"saveSettingdialogDescription": "Specificare interval auto-salvare",
	"saveSettingdialogParamName": "Interval auto-salvare",
	"saveSettingdialogParamLabel": "min",
	"saveSettingdialogButtonOk": "Setare interval",
	"saveSettingdialogButtonCancel": "Anulare",
	"saveMessageSuccess": "Salvat la ${0}",
	"saveMessageFail": "A eşuat să salveze la${0}"
})

//end v1.x content
);
