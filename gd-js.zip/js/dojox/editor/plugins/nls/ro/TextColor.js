//>>built
define(
//begin v1.x content
({
	"setButtonText": "Setare",
	"cancelButtonText": "Anulare"
})

//end v1.x content
);
