//>>built
define(
//begin v1.x content
({
	"preview": "Eksempel"
})

//end v1.x content
);
