//>>built
define(
//begin v1.x content
({
	"pageBreak": "Sideskift"
})

//end v1.x content
);
