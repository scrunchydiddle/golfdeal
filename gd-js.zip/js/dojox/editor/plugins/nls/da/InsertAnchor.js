//>>built
define(
//begin v1.x content
({
	insertAnchor: "Indsæt anker",
	title: "Ankeregenskaber",
	anchor: "Navn:",
	text: "Beskrivelse:",
	set: "Definér",
	cancel: "Annullér"
})

//end v1.x content
);
