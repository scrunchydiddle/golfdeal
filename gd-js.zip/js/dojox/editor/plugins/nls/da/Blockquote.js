//>>built
define(
//begin v1.x content
({
	"blockquote": "Citat"
})

//end v1.x content
);
