//>>built
define(
//begin v1.x content
({
	"showBlockNodes": "Vis HTML-blokelementer"
})

//end v1.x content
);
